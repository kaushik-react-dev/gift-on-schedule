import React, { useState } from "react";
import Logo from "../../assets/logo";
import Step01 from "../../components/details/steps/step01";
import Step02 from "../../components/details/steps/step02";
import Step03 from "../../components/details/steps/step03";
import Step04 from "../../components/details/steps/step04";
import Step06 from "../../components/details/steps/step06";
import Step05 from "../../components/details/steps/step05";
import Step07 from "../../components/details/steps/step07";
import Footer from "../../common/footer";
import { useSelector } from "react-redux";
import UnwrapGift01 from "../../components/details/unwrapGift01";
import UnwrapGift02 from "../../components/details/unwrapGift02";

const Details = () => {
  const step = useSelector((state: any) => state?.counter?.step);
  const [giftStep, setGiftStep] = useState(1);

  const handleSteps: any = (data: number) => {
    if (data === 1) {
      return <Step01 />;
    }
    if (data === 2) {
      return <Step02 />;
    }
    if (data === 3) {
      return <Step03 />;
    }
    if (data === 4) {
      return <Step04 />;
    }
    if (data === 5) {
      return <Step05 />;
    }
    if (data === 6) {
      return <Step06 />;
    }
    if (data === 8) {
      return <Step07 />;
    }
  };

  return (
    <>
      {step !== 0 ? (
        <>
          <div
            className={`${
              step % 2 === 1 ? "details-bg" : "bg-white"
            } h-[100vh] min-h-[1024px]  flex justify-center`}
          >
            <div className="md:flex block w-[70%] mt-[55px]">
              <div className="flex justify-center">
                <Logo />
              </div>
              <div className="w-full flex justify-center mt-4">
                {handleSteps(step)}
              </div>
            </div>
          </div>
          <Footer />
        </>
      ) : (
        <>
          <UnwrapGift01 />
          {/* <UnwrapGift02 /> */}
        </>
      )}
    </>
  );
};

export default Details;
