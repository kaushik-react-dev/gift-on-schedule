import React from "react";
import { Select } from "antd";
import "../../styles/style.css"

interface customSelectProp {
  inputPlace: string;
}

const CustomSelect = ({ inputPlace }: customSelectProp) => {
  return (
    <Select
      showSearch
      style={{ width: "340px", height: "48px",  }}
      className="rounded-none"
      
      placeholder={inputPlace}
      optionFilterProp="children"
      filterOption={(input, option) => (option?.label ?? "").includes(input)}
      filterSort={(optionA, optionB) =>
        (optionA?.label ?? "")
          .toLowerCase()
          .localeCompare((optionB?.label ?? "").toLowerCase())
      }
      options={[
        {
          value: "1",
          label: "USA",
        },
        {
          value: "2",
          label: "Canada",
        },
        {
          value: "3",
          label: "Other",
        },
      ]}
    />
  );
};

export default CustomSelect;
