import { configureStore } from "@reduxjs/toolkit";
import stepCounterReducer from "./slices/stepsCounter";

export const store = configureStore({
  reducer: { counter: stepCounterReducer },
});
